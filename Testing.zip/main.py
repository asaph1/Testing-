import os
import requests
import telepot
import time
import random
from telepot.namedtuple import InlineKeyboardMarkup, InlineKeyboardButton

# Replace with your bot's API token
bot_token = "7464380092:AAFvHj3ShrG4VefGY1BCj0L3-8eVRHJbro4"

# Replace with your Telegram channel's ID
channel_id = "@trending_gemz"

bot = telepot.Bot(bot_token)

# Initialize the last posted timestamp
last_posted_timestamp = 0

# Function to fetch data from CoinMarketCap API
def fetch_latest_tokens():
    try:
        url = 'https://pro-api.coinmarketcap.com/v1/cryptocurrency/listings/latest'
        headers = {
            'Accepts': 'application/json',
            'X-CMC_PRO_API_KEY': '6c28cf41-41b1-43a6-9029-478dd085df50',  # Replace with your CoinMarketCap API key
        }
        params = {
            'limit': 150,  # Fetch up to 150 latest tokens (adjust as per your needs)
            'sort': 'date_added',  # Sort by date added
            'sort_dir': 'desc',  # Newest first
        }
        response = requests.get(url, headers=headers, params=params)
        response.raise_for_status()  # Raise exception for bad status codes
        return response.json()
    except requests.exceptions.RequestException as e:
        print(f"Error fetching latest tokens: {e}")
        return None

# Function to format and send message to Telegram channel
def send_message_to_channel(token):
    try:
        # Fetch social media links
        urls = token.get('urls', {})
        twitter = urls.get('twitter', ['None'])[0] if urls else 'None'
        telegram = urls.get('telegram', ['None'])[0] if urls else 'None'
        website = urls.get('website', ['None'])[0] if urls else 'None'

        # Determine the network
        platforms = token.get('platform', {})
        network = platforms.get('name', 'Others')
        contract_address = platforms.get('token_address', 'N/A')

        message = f"Token: {token['name']}\n"
        message += "💚 " * 13 + "\n\n"
        message += f"🌱 {token['name']} • ${token['symbol']} 🌱\n"
        message += f"🌐 Network: {network}\n\n"
        message += f"📖 Description: {token.get('description', 'N/A')}\n\n"
        message += "📱 Socials:\n"
        message += f"       ├─ Telegram: {telegram}\n"
        message += f"       ├─ X: {twitter}\n"
        message += f"       └─ Other: {website}\n\n"
        message += f"💎 Tokenomics:\n"
        message += f"       ├─ 🏷 Name: {token['name']}\n"
        message += f"       ├─ 💲 Symbol: ${token['symbol']}\n"
        message += f"       ├─ 💰 Total Supply: {float(token.get('total_supply', 0)):,.6f}\n"
        message += f"       ├─ 📤 Tax: {token.get('tax', '0%')}\n"
        message += f"       └─ 🔷 Decimals: {token.get('decimals', 'N/A')}\n"
        message += f"       ├─ 🏠 Contract Address: {contract_address}\n\n"
        message += "🔒 Trade:\n"
        message += f"       ├─ ✅ 24hrs High: {float(token['quote']['USD'].get('high_24h', 0)):,.2f}\n"
        message += f"       ├─ ✅ 24hrs Low: {float(token['quote']['USD'].get('low_24h', 0)):,.2f}\n"
        message += f"       ├─ ✅ 24hrs Volume: {float(token['quote']['USD'].get('volume_24h', 0)):,.2f}\n"
        message += f"       ├─ ✅ Circulating Supply: {float(token.get('circulating_supply', 0)):,.2f}\n"
        message += f"       └─ ✅ Market Cap: {float(token['quote']['USD'].get('market_cap', 0)):,.2f}\n\n"
        message += "👤 Creator Details:\n"
        message += f"       ├─ 💵 Balance: {token.get('creator_balance', 'N/A')} (${token.get('creator_balance_usd', 'N/A')})\n"
        message += f"       ├─ 🖨 Transactions: {token.get('transactions', 'N/A')}\n"
        message += f"       ├─ {dev_wallet_status(token.get('creator_balance_usd', 0))}\n"
        message += "       └─ 🟠 Low Number Of Transactions\n\n"

        keyboard = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="Follow on X", url="https://x.com/dev_web_")],
            [InlineKeyboardButton(text="Follow on Telegram", url="https://t.me/dev_web4")]
        ])

        bot.sendMessage(channel_id, message, reply_markup=keyboard)
    except KeyError as e:
        print(f"Error processing token data: Missing key {e}")
    except Exception as e:
        print(f"Error processing token {token['name']}: {e}")

# Function to determine the dev wallet status based on balance
def dev_wallet_status(balance_usd):
    try:
        balance_usd = float(balance_usd)
    except ValueError:
        balance_usd = 0
    
    if balance_usd < 2000:
        return "🟠 Dev Wallet Almost Dry"
    elif 2000 <= balance_usd <= 10000:
        return "🟡 Dev Wallet Moderate"
    else:
        return "🟢 Dev Wallet Good"

# Main loop to periodically fetch and post data
if __name__ == '__main__':
    while True:
        try:
            latest_tokens = fetch_latest_tokens()
            if latest_tokens and 'data' in latest_tokens:
                tokens = latest_tokens['data']
                random.shuffle(tokens)  # Shuffle the list to randomize the order
                for token in tokens:
                    timestamp = int(token['date_added'].split('T')[0].replace('-', ''))
                    if timestamp > last_posted_timestamp:
                        send_message_to_channel(token)
                        last_posted_timestamp = timestamp
                        time.sleep(6)  # Wait for 60 seconds before sending the next token
        except Exception as e:
            print(f"Main loop error: {e}")
        time.sleep(6)  # Wait for 60 seconds before fetching the latest tokens again